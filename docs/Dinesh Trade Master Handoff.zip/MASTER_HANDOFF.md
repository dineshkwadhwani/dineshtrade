# DineshTrade — Master Handoff Document
**Version:** 3.0 | **Date:** June 21, 2026  
**Author:** Dinesh Wadhwani  
**Purpose:** Complete knowledge transfer — every decision, rule, architecture, and context needed to continue building DineshTrade without losing anything.

> **How to use this document:** Upload this file at the start of every new Claude/Copilot session and say: "Read MASTER_HANDOFF.md first. This is DineshTrade context."

---

## PART 1 — WHO IS DINESH AND WHAT IS THIS

**Dinesh Wadhwani** — Senior Director of Engineering at NICE Ltd (day job), founder of DineshTrade (personal project).  
**Location:** Pune, Maharashtra, India  
**Email:** dinesh.k.wadhwani@gmail.com  
**DineshTrade has nothing to do with StudioVerse or any other Dinesh venture.**

### Trading Background

Dinesh has been trading Indian equities since FY2020 across 4 family accounts plus helping ~10 friends/family trade manually.

| Account | Relation | Broker | Status |
|---|---|---|---|
| Dinesh Wadhwani (DINESH) | Self | Zerodha | Primary — in app |
| Kiran Wadhwani | Wife | Motilal Oswal | Manual |
| Sheela Wadhwani | Mother | Motilal Oswal | Manual |
| Sonia Wadhwani (CJD607) | Daughter | Zerodha | In app |

### Verified P&L (FY2020–2026)

| Account | Net Realised P&L | Best Year |
|---|---|---|
| Dinesh | ₹7,28,820 | 17.5% FY23-24 |
| Kiran | ₹27,68,752 | 20.8% FY23-24 |
| Sheela | ₹19,35,215 | 11.1% FY23-24 |
| Sonia | ₹4,96,373 | 2.2% FY24-26 |
| **TOTAL** | **₹59,28,726** | FY23-24: ₹26.56L in one year |

Win rate: 94–100% in peak years. Total brokerage paid over 6 years: ₹4,89,748.

---

## PART 2 — TRADING PHILOSOPHY (NEVER VIOLATE)

```
1. Never short sell
2. Never trade F&O
3. Never sell at a loss (auto mode) — wait for recovery
4. Buy blue chips on dips — they always come back
5. LIFO approach — last trade on each script always profitable
6. List A is config-locked — cannot add stocks via UI impulsively
7. Only NSE cash equity, CNC delivery orders
8. 5% of capital per trade maximum
```

These are not parameters. They are laws. The no-loss gate (rule 3) is enforced in code at `lib/preflight.ts` GATE 9. The only bypasses are `squareOffEOD` and `pivotalStopLoss` — both require explicit audit trail.

---

## PART 3 — CURRENT APPLICATION (v1 — LIVE)

### Deployment

- **URL:** https://dineshtrade.online
- **Server:** AWS EC2 ap-south-1 (Mumbai), Elastic IP 3.111.255.172
- **Process:** PM2 `dineshtrade`, Node 20 LTS
- **Reverse proxy:** Caddy (handles HTTPS)
- **Repo:** ~/dineshtrade on EC2

### Tech Stack

```
Framework:    Next.js 14, App Router, TypeScript
Styling:      Tailwind CSS + custom dt-* CSS class system
Theme:        Obsidian Gold dark (default) + Light mode toggle
Fonts:        Cormorant Garamond (serif), Outfit (body), JetBrains Mono (numbers)
Server:       Custom Node.js server (server.js) — wraps Next.js + starts node-cron
Cron:         node-cron in same process as Next.js
Broker:       Zerodha Kite Connect (REST API)
Auth:         Time-based password (ddmmyyyyhh IST) + JWT cookie
State:        JSON files on disk (config/ and data/)
Email:        Nodemailer + Gmail SMTP (App Password — FREE, not Google API)
AI:           Gemini 2.5 Flash (AI_PROVIDER=GEMINI)
```

### Pages

| Page | Path | Purpose |
|---|---|---|
| Login | /login | Time-based password auth |
| Dashboard | /dashboard | Morning briefing, GIFT Nifty, global indices |
| Watchlist | /watchlist | Read-only live LTP per list tab — NEVER originates orders |
| Manage Lists | /manage-lists | Create/rename/delete watchlists |
| Pivotal Lists | /pivotal-lists | Per-script trigger/target/SL editor |
| Trading Engine | /engine | Recommendations, scan tiles, Execute, pending orders |
| Current Holdings | /holdings | Holdings + T0 positions merged, B/S buttons |
| Today's Positions | /positions | Open day positions, live P&L, Square Off |
| Today's Orders | /trades | Order log + Retrospective tab |
| Trade Report | /trade-report | Date-range P&L from journal |
| Settings | /settings | Accounts, strategy editor, backtest, Reset |

### Authentication

- Password format: `ddmmyyyyhh` (e.g. 21062026 at 14:xx IST = `2106202614`)
- Session: JWT cookie, expires midnight IST
- Login with Kite button → `/api/zerodha/login` → Kite OAuth → token stored in state.json

### Environment Variables (EC2 .env)

```bash
SESSION_SECRET=                        # 32+ random chars
STATE_FILE_PATH=/home/ubuntu/dineshtrade/data/state.json
CRON_ENABLED=true
ZERODHA_ENVIRONMENT=PROD
ZERODHA_ACCOUNT1=DINESH
ZERODHA_ACCOUNT2=SONIA
PROD_ZERODHA_API_KEY_DINESH=
PROD_ZERODHA_API_SECRET_DINESH=
PROD_ZERODHA_API_KEY_SONIA=
PROD_ZERODHA_API_SECRET_SONIA=
AI_PROVIDER=GEMINI
AI_GEMINI_API_KEY=
AI_MODEL=gemini-2.5-flash
SMTP_USER=dinesh.k.wadhwani@gmail.com
SMTP_PASS=                             # 16-char Google App Password
NOTIFY_TO=dinesh.k.wadhwani@gmail.com
```

### Deploy Runbook

```bash
cd ~/dineshtrade
git pull
rm -rf .next
npm ci
NODE_OPTIONS="--max-old-space-size=2048" npm run build
pm2 restart dineshtrade --update-env
```

### Data Files (NEVER touch during deploy)

```
~/dineshtrade/data/
  state.json             mode, tokens, idempotency ledger, buy history, panic skip
  strategy.json          runtime overlay of bundled strategy config (user edits)
  watchlist.json         runtime watchlist overlay
  positions.json         unified position store (all strategies, all accounts)
  daily-closes.json      rolling 60-day close price cache
  journal-YYYY-MM.jsonl  append-only trade journal
  backtest-history.json  saved backtest runs
```

---

## PART 4 — CODEBASE STRUCTURE

```
lib/
  kite.ts              Zerodha Kite Connect REST wrapper
  strategyConfig.ts    Strategy type definitions + config accessors
  strategyConfigStore.ts  Runtime config (reads data/strategy.json overlay)
  strategyEngine.ts    Main BUY scan engine (dip + momentum + pivotal)
  strategy1.ts         Accumulator (dip) SELL monitor
  strategy2.ts         Catalyst/Momentum SELL monitor
  strategy2Positions.ts   Momentum position helpers
  pivotal.ts           Pivotal scanner + SELL monitor
  pivotalListStore.ts  Pivotal list CRUD (config/pivotalLists.json)
  preflight.ts         ALL pre-flight gates (no-loss, idempotency, etc.)
  positions.ts         Unified position store (positions.json)
  journal.ts           Trade journal (journal-YYYY-MM.jsonl)
  state.ts             App state (state.json — mode, tokens, counters)
  accounts.ts          Account config (config/accounts.json + env vars)
  watchlistStore.ts    Watchlist CRUD (config/watchlist.json)
  cron.ts              Cron orchestrator (registers all tasks, start/stop)
  cronBuy.ts           Auto-buy engine
  cronEOD.ts           EOD square-off + daily retrospective
  cronReconcile.ts     Manual sell detection
  cronState.ts         Cron state helpers (in-process counters, roll day)
  backtest.ts          Backtesting engine
  backtestHistory.ts   Backtest history store
  ema.ts               EMA calculation
  dailyCloses.ts       Daily close price cache
  instruments.ts       NSE instrument token lookup
  intradayCircuit.ts   Intraday circuit breaker (live Nifty)
  panicSell.ts         Panic sell detection (per-symbol)
  retrospective.ts     Daily/monthly report builder
  tradeReport.ts       Trade report generation
  email.ts             Nodemailer + Gmail SMTP
  auth.ts              JWT cookie session
  ai.ts                Gemini AI integration
  market.ts            Market hours + holiday check
  strategyTag.ts       resolvePositionTag() helper (centralized tag logic)

config/ (bundled defaults — in repo)
  strategy.json        Strategy definitions + capital config
  watchlist.json       Watchlists (listA, listB, etc.)
  pivotalLists.json    Pivotal list entries
  accounts.json        Account display names (DINESH, SONIA)
  holidays.json        NSE holiday calendar

data/ (runtime — NOT in repo, on EC2 only)
  state.json           Runtime state
  strategy.json        Runtime strategy overlay
  positions.json       Live positions
  journal-*.jsonl      Trade journals
  etc.
```

### Key Architectural Patterns

**1. Runtime Strategy Overlay**
`config/strategy.json` = bundled defaults (in repo). `data/strategy.json` = user edits via Settings UI (NOT in repo). `lib/strategyConfigStore.ts` reads overlay first, falls back to bundled. This is why Settings changes persist across deploys.

**2. Idempotency**
Prevents double-buying. Key = `account:symbol:BUY:YYYY-MM-DD`. Stored in `state.json`. Expires at IST midnight. Prevents duplicate buys even if two cron tasks fire simultaneously.

**3. In-Process Race Condition Guards**
`cronState.ts` maintains `inProcessBuyCounts` and `inProcessNewSymbols` counters. Two concurrent strategy tasks can both pass Gate 5 (day quota) before either's order shows COMPLETE in Kite. These in-process counters close the race. Reset at midnight via `maybeRollDay()`.

**4. Position Lots**
Each position has a `lots` array tracking individual BUY entries. `firstBuyPrice` is set at first BUY, never changed by pyramid adds. All exit targets (T1, T2) are anchored to `firstBuyPrice`, not average price.

**5. Strategy Tags**
Every order tagged: `dt-accumulator`, `dt-catalyst`, `dt-s2-exit`, `dt-eod-catalyst`, etc. Tags link orders to strategies across all pages. `lib/strategyTag.ts` centralises `resolvePositionTag()`.

**6. Holdings Bug (Fixed 28 May 2026)**
CNC positions bought yesterday move from Kite's `/portfolio/positions` to `/portfolio/holdings` overnight. Fix: `strategy2.ts` monitor builds `liveQtyBySymbol` from BOTH holdings + positions. `buildLiveQtyBySymbol()` helper in `lib/kite.ts`.

**7. Journal-Based Reseeding (Seed 2)**
If a momentum position falls out of the store (OOS after overnight migration), the monitor reads last 30 days of journal BUYs and reseeds from the earliest auto-BUY record. Prevents positions from being orphaned.

**8. Manual Sell Reconciliation**
`cronReconcile.ts` runs every 5-min tick + at 15:35. Detects Kite qty = 0 but position still in store. Journals a synthetic SELL at actual fill price (today) or LTP (prior day). Removes closed row from positions store. Critical: prevents stale `firstBuyPrice` anchors from poisoning a later re-buy.

---

## PART 5 — ALL STRATEGIES IN DETAIL

### Shared Capital Config (current live values)

```
perTrade:              ₹10,000 (5% of ₹2L capital)
maxBuysPerDay:         10
maxSellsPerDay:        20
deliveryDpCharge:      ₹15.34 (Zerodha) — used in net P&L calculations
circuitBreakerPct:     -5% (GIFT Nifty pre-market)
intradayCircuitTripPct: -3% (live Nifty from open)
intradayCircuitResumePct: -2% (hysteresis)
panicDropPct:          10% (per-symbol in panicWindowMin)
panicWindowMin:        10 min
maxDeployPct:          100%
sharedPool:            true
maxOpenPositions:      25
maxBuysPerSymbol:      3 (pyramid cap)
minDropBetweenBuysPct: 10%
```

---

### Strategy 1 — Accumulator (Dip / Mean Reversion)

**ID:** `accumulator` | **Type:** `dip` | **Status:** Always ACTIVE — cannot delete

**Philosophy:** Buy quality stocks when they dip below 20-day EMA. Wait for recovery. Exit in two tranches. This is also the universal "parking lot" — all failed momentum positions hand off here.

**Current Parameters:**
```
scanIntervalMin:       15
watchlist:             listA
emaPeriod:             20
entryBelowPct:         5% (minimum dip below EMA)
strongBuyBelowPct:     8% (higher conviction tier — same entry logic)
minDownDays:           3 (consecutive down days required)
capitulationFloorPct:  12% (skip — news/panic event, not mean reversion)
tranche2AboveEMAPct:   3% (T2 fires at EMA + 3%)
reactiveDrop:          3% (intraday drop triggers off-cycle scan)
reactiveIntervalMin:   30 (throttle reactive scans)
firesOnAnyMode:        true (reactive scan fires even in momentum mode)
maxPerSector:          3 (sector concentration cap)
T1:                    3%
T2:                    7%
GIFT Nifty gate:       enabled, maxPct = -0.5% (fires on flat/negative days)
```

**Entry Logic:**
1. LTP ≤ EMA × (1 - 0.05) — at least 5% below 20-day EMA
2. ≥3 consecutive down days
3. LTP > EMA × (1 - 0.12) — not in capitulation zone (not news crash)
4. GIFT Nifty ≤ -0.5% (weak market day)
5. Sector count < maxPerSector (3) for this symbol's sector
6. All preflight gates pass

**Exit Logic (Two-Tranche, anchored to firstBuyPrice):**
- **T1:** LTP ≥ firstBuyPrice × 1.03 → sell 50% of remainingQty
- **T2:** LTP ≥ firstBuyPrice × 1.07 → sell remaining 50%
- **T2 jump:** If T2 hit before T1 → sell entire position at T2
- **tranche2AboveEMA:** LTP ≥ EMA × 1.03 also triggers T2

**Handoff Receipt:**
When Catalyst/Momentum position ages past deliveryHandoffDays, `ensureStrategy1Tracking()` re-stamps strategyId to 'accumulator'. firstBuyPrice and firstBuyAt preserved from original entry.

**Reactive Scan:**
Any listA stock drops ≥3% intraday → off-cycle scan fires (throttled to max 1/30min).

---

### Strategy 2 — Catalyst (Momentum)

**ID:** `catalyst` | **Type:** `momentum` | **Status:** ACTIVE

**Philosophy:** Catch stocks already moving up today on momentum. Quick in-and-out. Entry thesis is valid only for today — dead by EOD if it didn't fire.

**Current Parameters:**
```
scanIntervalMin:           3
watchlist:                 listA
minDayGainPct:             0.5%
maxDayGainPct:             1.0%
consecutiveCandles:        3 (rising 5-min candles)
emaProximityPct:           3% (LTP within ±3% of EMA)
volumeAvgDays:             10
scanStartHHMM:             09:15
scanEndHHMM:               15:00
deliveryHandoffDays:       15
exitSameDayTime:           15:15
exitSameDayOnPositive:     true
squareOffEOD:              false
T1:                        1.5%
T2:                        2.0%
GIFT Nifty gate:           disabled (fires any day)
```

**Entry Logic:**
1. Day gain between 0.5% and 1.0%
2. Last 3 consecutive 5-min candles all rising
3. LTP within ±3% of 20-day EMA
4. Time between 09:15 and 15:00 IST
5. All preflight gates pass

**Exit Logic:**
- **Candle-high check (CRITICAL):** On every sell monitor tick, checks BOTH current LTP AND the HIGH of the last completed 5-min candle. If candle high crossed T1/T2 but LTP has since retreated → sell at current market price immediately. Prevents missed exits when price spikes between cron ticks.
- **T1:** LTP ≥ firstBuyPrice × 1.015 → sell 100% (momentum = full exit)
- **T2:** LTP ≥ firstBuyPrice × 1.020 → sell 100%
- **EOD at 15:15:** exitSameDayOnPositive = true
  - Calculates estimated net P&L after charges
  - Same-day position: no DP charge in estimate
  - Multi-day position: includes DP charge (₹15.34)
  - If net P&L > 0 → sell immediately (free capital for tomorrow)
  - If net P&L ≤ 0 → hold (no-loss gate applies)
  - Re-checks every 5-min tick until market close

**Delivery Handoff:**
After 15 calendar days from firstBuyAt → re-tag to 'accumulator'.

---

### Strategy 3 — Market Boom (Momentum)

**ID:** `market_boom` | **Type:** `momentum` | **Status:** INACTIVE (activate on boom days)

**Philosophy:** Capture multiple small gains on strong gap-up days. Always square off EOD — never takes delivery.

**Current Parameters:**
```
scanIntervalMin:       5
watchlist:             listA
minDayGainPct:         0.5%
maxDayGainPct:         1.0%
consecutiveCandles:    2
emaProximityPct:       5%
volumeAvgDays:         5
scanStartHHMM:         09:30
scanEndHHMM:           15:15
deliveryHandoffDays:   15 ← BUG: should be 0 (see known bugs)
exitSameDayTime:       15:10
exitSameDayOnPositive: true
squareOffEOD:          false ← BUG: should be true (see known bugs)
T1:                    1.0%
T2:                    2.0%
GIFT Nifty gate:       enabled, minPct = +1% (only on strong gap-up days)
```

**⚠️ KNOWN BUG:** squareOffEOD should be `true` and deliveryHandoffDays should be `0`. Currently set wrong. Market Boom positions are accidentally going to delivery. Fix before activating.

---

### Strategy 4 — Pivotal (Livermore Breakout)

**ID:** `new_pivotal` | **Type:** `pivotal` | **Status:** ACTIVE

**Philosophy:** Jesse Livermore's Pivotal Point concept. Stock consolidates in a tight range for ~10 days (volume dries up), then breaks out above the range with volume surge. Buy the breakout. Each symbol has its own trigger price, targets, and optional stop-loss.

**Architecture Difference:** Unlike Dip and Momentum which apply uniform params to all watchlist symbols, Pivotal uses a **Pivotal List** for per-symbol configuration. Strategy-level params define HOW to validate breakouts; the Pivotal List defines the trade thesis per symbol.

**Strategy-Level Parameters:**
```
consolidationDays:              10
consolidationMaxRangePct:       6%
volumeAvgDays:                  10
minVolumeSurgeRatio:            1.2×
minDayGainPct:                  1%
maxDayGainPct:                  4%
breakoutConfirmCandles:         2
scanStartHHMM:                  10:00
scanEndHHMM:                    13:00
minProjectedVolumeCheckHHMM:    10:00
dayEndExecutionTime:            15:10
deliveryHandoffDays:            15
pivotalListId:                  pivotalA
T1 (default fallback):          2%
T2 (default fallback):          3.5%
GIFT Nifty gate:                disabled
```

**Per-Symbol Pivotal List Fields:**
```
symbol                NSE ticker
name                  Display name
enabled               Active for scanning
breakoutTriggerPrice  THE execution trigger — always controls entry
t1Pct                 First target % (overrides strategy default)
t2Pct                 Second target % (overrides strategy default)
executionMode         'normal' (intraday) | 'dayEnd' (sustain-into-close)
stopLossPrice         Optional. Hard exit below this (overrides no-loss gate)
notes                 Context
```

**Validation rules:**
- breakoutTriggerPrice > 0 (required, always controls entry)
- t1Pct > 0, t2Pct > 0, t1Pct ≤ t2Pct
- stopLossPrice (if set) must be STRICTLY < breakoutTriggerPrice
- Consolidation high = validation/warning only, NEVER execution trigger

**Normal Mode Entry:**
1. Time between 10:00 and 13:00 IST
2. LTP > breakoutTriggerPrice
3. Day gain between 1% and 4%
4. Last 2 consecutive 5-min candles rising
5. Consolidation: last 10 days (high-low range)/low ≤ 6%
6. Volume: projectedDayVolume ≥ avgVolume × 1.2
   - `projectedDayVolume = currentVolume / (minutesElapsed / 375)`
   - Only evaluated after 10:00 IST (minProjectedVolumeCheckHHMM)
7. All preflight gates pass

**DayEnd Mode Entry:**
1. No intraday buy — waits until dayEndExecutionTime (15:10)
2. At 15:10: LTP still > breakoutTriggerPrice
3. Consolidation validation passes
4. Realized day volume ≥ avgVolume × 1.2 (no projection)

**Exit Priority Order:**
1. Stop-loss: LTP ≤ stopLossPrice → sell immediately (bypass no-loss gate)
2. T2: LTP ≥ entryPrice × (1 + t2Pct/100) → sell 100%
3. T1: LTP ≥ entryPrice × (1 + t1Pct/100) → sell 100%
4. Delivery handoff: age > 15 days → hand to Accumulator

---

## PART 6 — PREFLIGHT GATES (Complete)

All 9 gates in `lib/preflight.ts`, in sequence:

```
GATE 1:  Token connected (state.kiteTokens[account] exists)
GATE 2:  Market open + not NSE holiday
GATE 2b: [BUY auto] Intraday circuit not tripped
GATE 3:  [BUY auto] tradeValue ≤ capital.perTrade
GATE 4:  [BUY auto] Idempotency — not bought this symbol today
GATE 4b: [BUY auto] Panic sell — symbol not in daily panic list
GATE 4c: [BUY auto] Pyramid — not at maxBuysPerSymbol, drop % met
GATE 4d: [BUY auto dip] Sector concentration < maxPerSector
GATE 5:  [auto] Day quota — maxBuysPerDay / maxSellsPerDay not exceeded
GATE 6:  [BUY auto] Open positions < maxPositions
GATE 7:  [BUY] Funds available ≥ tradeValue
GATE 8:  [SELL] Held qty > 0 (no short). Clamps qty to held if held < requested.
GATE 9:  [SELL auto] LTP ≥ average_price (NO LOSS SELL)
         BYPASSED only by:
           bypassNoLossSellReason = 'squareOffEOD'
           bypassNoLossSellReason = 'pivotalStopLoss'
```

Manual orders bypass: GATE 3, 4, 4b, 4c, 4d, 5, 9. Funds (7) and no-short (8) always apply.

---

## PART 7 — EOD BEHAVIOUR MATRIX

| exitSameDayOnPositive | squareOffEOD | Behaviour at exitSameDayTime |
|---|---|---|
| false | false | No EOD action. Hold for T1/T2 or delivery handoff. |
| true | false | Sell if estimated net P&L (after charges incl. DP if multi-day) > 0. |
| true | true | Sell ALL positions regardless of P&L. squareOffEOD wins. |
| false | true | Sell ALL positions regardless of P&L. squareOffEOD wins. |

**Exit Rule Hierarchy (highest to lowest priority):**
1. squareOffEOD — overrides everything including no-loss gate
2. Pivotal stop-loss — overrides no-loss gate for that symbol
3. T2 exit — full position sell
4. T1 exit — 50% (dip) or 100% (momentum/pivotal)
5. exitSameDayOnPositive — EOD capital freeing
6. Delivery handoff — after N days → Accumulator
7. No-loss gate — never sell below average cost (default, always active)

---

## PART 8 — CRON ARCHITECTURE

### Cron Schedule

```
Every 5 min (09:15–15:30, weekdays):
  Global tick — runs ALL of:
    strategy2.monitorAllConnected() — Momentum SELL monitor
    strategy1.monitorAllAccountsStrategy1() — Accumulator SELL monitor
    pivotal.monitorAllPivotalAccounts() — Pivotal SELL monitor
    cronEOD.runEODSquareOff() — EOD checks (after exitSameDayTime)
    cronReconcile.reconcileManualSells() — detect manual closes

Per strategy (on strategy.scanIntervalMin schedule):
  Accumulator:   every 15 min
  Catalyst:      every 3 min
  Market Boom:   every 5 min
  Pivotal:       every 5 min

  Each fires:    runStrategyTaskBody(strategy) → runStrategyScan() → autoBuyOnAccount()

15:35 IST:       dailyRetrospective() — daily email report
Last trading day of month: monthly rollup email
```

### Server Architecture

```
server.js (custom Node server)
  → app.prepare() (Next.js)
  → startCron() (lib/cron.ts)
  → createServer() (HTTP)

lib/cron.ts registers:
  - tickTask: every 5 min
  - eodTask: 15:35 IST
  - per-strategy tasks (one per active strategy, at scanIntervalMin)

All run in same Node process as Next.js (PM2 keeps it alive)
```

---

## PART 9 — CHARGE MODEL

### Per ₹10,000 Trade — Zerodha

| Charge | Rate | Same-day | Delivery |
|---|---|---|---|
| Brokerage | ₹0 | ₹0 | ₹0 |
| STT | 0.025% sell | ₹2.50 | ₹2.50 |
| Exchange NSE | 0.00345% both | ₹3.45 | ₹3.45 |
| Stamp duty | 0.003% buy | ₹3.00 | ₹3.00 |
| SEBI + IPFT | 0.0001% both | ₹0.02 | ₹0.02 |
| GST | 18% on fees | ₹1.17 | ₹1.17 |
| DP charge | ₹15.34 flat | ₹0 | ₹15.34 |
| **Total** | | **~₹10** | **~₹25.50** |
| **Breakeven** | | **0.10%** | **0.26%** |

### EOD Net P&L Estimation (in code)

```typescript
function estimateExitNetPnl(firstBuyAt, entryPrice, exitPrice, qty) {
  const mode = firstBuyAt.slice(0,10) === today ? 'intraday' : 'delivery'
  const charges = estimateBacktestCharges(mode, buyValue, sellValue, ...)
  return (sellValue - buyValue) - charges
}
// exitSameDayOnPositive fires only when this > 0
```

---

## PART 10 — WATCHLISTS

### Current Lists

- **listA** — 40+ blue-chip NSE stocks. Used by Accumulator, Catalyst, Pivotal. Config-locked — cannot add via UI.
- **listB** — Opportunistic/higher volatility. Used by Market Boom.
- **QuickWins** — Quality but fast capital cycling. exitSameDayOnPositive = true always.

### listA Contents (as of June 2026)

AXISBANK, BAJAJ-AUTO, BAJAJFINSV, BAJFINANCE, BANKINDIA, BIRLACORPN, BSE, BSOFT, CAMS, COCHINSHIP, HDFCAMC, HDFCBANK, HEROMOTOCO, HYUNDAI, ICICIBANK, ICICIPRULLI, INDUSINDBK, INFY, INTELLECT, ITC, JINDALSTEL, JIOFIN, JSWSTEEL, M&M, M&MFIN, MARUTI, MCX, OFSS, PERSISTENT, PNB, RELIANCE, SAIL, SBIN, SIEMENS, TATACHEM, TATAPOWER, TATASTEEL, TCS, TMPV, WIPRO

**Recommended additions (priority order):**
SUNPHARMA, HINDUNILVR, KOTAKBANK, NTPC, LT, CIPLA, ASIANPAINT, TITAN, COALINDIA, BHARTIARTL, DRREDDY, HINDALCO, ONGC, HCLTECH, ULTRACEMCO, ADANIPORTS, DIVISLAB, BRITANNIA, TECHM, BEL

---

## PART 11 — KNOWN BUGS (Fix in v2)

1. **Market Boom squareOffEOD = false** — MUST be `true`. Currently Market Boom positions go to delivery accidentally. Fix: set `squareOffEOD: true` in strategy config.

2. **Market Boom deliveryHandoffDays = 15** — MUST be `0`. With squareOffEOD = true, no position should ever reach delivery handoff. Fix alongside bug #1.

3. **Catalyst scanStartHHMM = 09:15** — First 15 minutes are extremely noisy. Should be `09:30`.

4. **Pivotal minVolumeSurgeRatio = 1.2** — Too low for genuine breakout confirmation. Should be `1.5`.

5. **Panic-Sell Drop = 10%** — By the time a stock drops 10% from its peak intraday it's already a disaster. Should be `4–5%`.

6. **Accumulator T2 differentiation** — Fresh dip entries (5% below EMA) deserve T1=3%, T2=7%. Catalyst handoff entries (entry near EMA) may benefit from T1=3%, T2=5%. Implement `positionSource` tagging ('dip' vs 'handoff') to differentiate in v2.

---

## PART 12 — THE v2 PLAN (DineshTrade SaaS)

### Why v2

1. **Angel One SmartAPI** — has a refresh token mechanism. No daily manual login after initial setup. Nightly cron refreshes token automatically. Free API (no ₹500/month).
2. **Supabase** — replaces JSON files with PostgreSQL. Enables multi-tenant SaaS. Row Level Security enforces tenant isolation.
3. **SaaS architecture** — multiple users, each with their own strategies, capital, positions.

### Broker Decision

| | Zerodha | Angel One |
|---|---|---|
| Brokerage (delivery) | ₹0 | ₹20 per round trip |
| STT | Same (govt charge) | Same |
| DP charge | ₹15.34/delivery sell | ₹20/delivery sell |
| API cost | ₹500/month | Free |
| Daily token | Manual login every day | Refresh token — once only |
| Static IP | One per account | Same |
| Break-even (API save vs extra charges) | | ~20 delivery trades/month |

**At current volume (60+ delivery trades/month): Zerodha is cheaper by ~₹980/month.**
**Real Angel One advantage: refresh token (no daily login) — architectural win for SaaS.**

### v2 Deployment Model

```
One EC2 instance per user (t3.micro ~$10/month + $3.50 Elastic IP)
Each instance = one Zerodha account = one static IP = fully compliant
Each user gets their own DineshTrade URL
Complete isolation — one user's crash never affects others
You manage a fleet of EC2s

Phase 1: Manual provisioning (5-10 users)
Phase 2: Docker image + automated EC2 provisioning (AWS SDK/Terraform)
Phase 3: Fully automated — user signs up, gets their instance in 10 minutes
```

### v2 Business Model

```
Fee structure: % of deployed capital per month (NOT % of profits)
  Avoids SEBI performance fee classification
  "1% of average deployed capital per month"
  
  User deploys ₹5L → you charge ₹5,000/month
  User deploys ₹10L → you charge ₹10,000/month
  
Break-even per user: ~₹1,300/month infra cost
Minimum viable user: ₹1.5L+ deployed capital
Target user: serious trader with ₹5L+

Legal framing (user agreement):
  "Platform usage fee for software infrastructure"
  "Strategies are owned and configured by the user"
  "We provide infrastructure, not advice"
  "We do not recommend securities"
```

### v2 Architecture

**What changes:**
- `lib/kite.ts` → `lib/broker/IBroker.ts` + `AngelOneAdapter.ts` + `ZerodhaAdapter.ts`
- `lib/accounts.ts` → reads from Supabase `accounts` table
- `lib/state.ts` → reads/writes Supabase `account_state`
- `lib/positions.ts` → reads/writes Supabase `positions`
- `lib/journal.ts` → reads/writes Supabase `journal`
- `lib/watchlistStore.ts` → reads/writes Supabase `watchlists`
- `lib/strategyConfigStore.ts` → reads Supabase `strategies` + `capital_config`
- `lib/auth.ts` → Supabase Auth (JWT + Row Level Security)
- Cron jobs → tenant-aware (loop all active users)
- Token management → nightly Angel One refresh token cron

**What does NOT change (strategy logic stays 100% identical):**
- lib/strategyEngine.ts
- lib/strategy1.ts
- lib/strategy2.ts
- lib/pivotal.ts
- lib/preflight.ts (except broker API calls)
- lib/cronEOD.ts
- lib/backtest.ts
- lib/ema.ts
- All trading rules and strategies

### v2 Supabase Schema (key tables)

```sql
users (id, email, role [retail|broker|admin], plan, created_at)
accounts (id, user_id, broker [angelone|zerodha], client_code, api_key,
          refresh_token_enc, access_token_enc, token_expiry, active, nickname)
strategies (id, user_id, name, type, params jsonb, exits jsonb,
            gift_nifty_gate jsonb, active, scan_interval_min, watchlist text[])
capital_config (user_id PRIMARY KEY, per_trade, max_buys_per_day, ...)
watchlists (id, user_id, list_key, name, symbols jsonb)
pivotal_lists (id, user_id, list_id, name, entries jsonb)
positions (id, user_id, account_id, strategy_id, symbol, remaining_qty,
           first_buy_price, first_buy_at, position_source, status, lots jsonb)
orders (id, user_id, account_id, strategy_id, symbol, side, qty, price,
        broker_order_id, tag, status, source, reason, created_at)
journal (id, user_id, account_id, strategy_id, event_type, symbol,
         detail jsonb, created_at)
backtest_runs (id, user_id, strategy_id, params jsonb, results jsonb, run_at)
account_state (account_id PRIMARY KEY, mode, idempotency_ledger jsonb,
               buy_history jsonb, daily_counters jsonb, circuit_state jsonb)
```

### v2 Build Phases

```
Phase 1 (Week 1-2): Foundation
  Supabase project setup (dev + prod)
  Schema creation + RLS policies
  Supabase Auth replacing lib/auth.ts
  Seed your data into Supabase
  Verify RLS: user A cannot see user B's data

Phase 2 (Week 2-3): Angel One Adapter
  IBroker interface (lib/broker/IBroker.ts)
  Angel One adapter (lib/broker/AngelOneAdapter.ts)
  Token refresh logic (nightly 23:50 IST cron)
  Replace kite.ts calls with adapter pattern
  Test manual order via Angel One

Phase 3 (Week 3-4): Engine Migration
  Replace all JSON file I/O with Supabase
  Make all cron jobs tenant-aware
  Test all strategies end-to-end
  Run parallel with v1 for validation

Phase 4 (Week 5-6): SaaS Layer
  User registration + onboarding
  Account connection wizard
  Per-user strategy management
  Dashboard

Phase 5 (Week 7-8): Broker Manager Role
  Manager-client relationships
  Manager dashboard
  Razorpay subscriptions
```

### Angel One Token Flow (v2)

```typescript
// One-time setup (user does once):
POST /rest/auth/angelbroking/user/v1/loginByPassword
→ jwtToken + refreshToken stored encrypted in Supabase

// Nightly 23:50 IST cron (automatic forever):
POST /rest/auth/angelbroking/jwt/v1/generateTokens
Body: { refreshToken: stored_refresh_token }
→ new jwtToken + new refreshToken
→ Update Supabase accounts table
→ Ready for next trading day
```

### Key Angel One API Differences vs Kite

| Feature | Zerodha Kite | Angel One SmartAPI |
|---|---|---|
| Base URL | api.kite.trade | apiconnect.angelone.in |
| Auth header | `token {apiKey}:{accessToken}` | `Bearer {jwtToken}` + `X-PrivateKey: {apiKey}` |
| Product (CNC) | `CNC` | `DELIVERY` |
| Orders | POST /orders/regular | POST /rest/secure/angelbroking/order/v1/placeOrder |
| Positions | GET /portfolio/positions | GET /rest/secure/.../getPosition |
| Holdings | GET /portfolio/holdings | GET /rest/secure/.../getHolding |
| Quotes | GET /quote?i=NSE:SYM | POST .../getMarketData |
| Historical | GET /instruments/historical/{token}/{interval} | POST .../getCandleData |
| Margins | GET /user/margins | GET .../getRMS |

### Supabase: Dev + Prod Projects

```
Free tier: 2 projects = dev + prod (both free)
dineshtrade-dev:  development + testing
dineshtrade-prod: live trading

Environment variables:
  .env.local:      SUPABASE_URL=dev URL
  .env.production: SUPABASE_URL=prod URL

Schema promotion: supabase db diff → supabase db push
```

---

## PART 13 — BACKTEST SYSTEM

### Backtest Parameters Saved Per Run

```
strategyName, strategyType, entryParams (full params object),
exitCriteria (T1%, T2%, squareOffEOD, exitSameDayOnPositive),
startingAmount, maxBuysPerDay, maxSellsPerDay, backtestDays,
closedTrades, openTrades, avgHoldDays, avgDrawdownPct,
netProfitRupees, netProfitPct, realizedProfitPct, winRate,
capitalEfficiency (netProfit / avgDeployedCapital × 100)
```

### Analyze Tests (AI-powered)

The "Analyse Tests" button on the Backtest tab calls Claude API with all stored runs. Analysis includes:
1. Overall winner by risk-adjusted return (net profit% ÷ drawdown%)
2. Quality score ranking (all runs)
3. Parameter sensitivity (how changing each param affected profit/drawdown)
4. Sweet spot detection (optimal value + diminishing returns point)
5. Consistency check (top 3 trades % of total profit — concentrated = unreliable)
6. Capital efficiency ranking
7. Final recommendation (one specific parameter set)

Costs ~₹3-5 per call. Shows confirmation dialog before firing.

---

## PART 14 — P&L REALITY CHECK (June 2026)

From the Zerodha ledger (May 19 – June 12, 2026):

```
Funds deposited:       ₹1,00,620
Closing balance:       ₹33,867.97
Realised P&L (gross):  +₹2,660
Charges & taxes:       -₹410.34 (exchange + STT + GST)
DP charges:            -₹260.78 (17 × ₹15.34)
API charges:           -₹500 (Kite Connect)
DDPI:                  -₹118 (one-time, never again)
Net realised P&L:      +₹1,370.88
Unrealised P&L:        -₹2,370 (open positions)
Combined:              -₹999.12 (system is 16 days old)
```

Key insight: 17 DP charges in 16 days = most positions going to delivery. `exitSameDayOnPositive` should reduce this significantly once it starts firing consistently.

---

## PART 15 — OPEN ITEMS / DECISIONS IN PROGRESS

### Immediate (before next trading session)
1. Fix Market Boom squareOffEOD = true and deliveryHandoffDays = 0 in config
2. Increase capital to ₹2,00,000 (trade size → ₹10,000, DP cost halves)

### Short Term (v1 improvements)
3. Accumulator T2: differentiate dip entries (keep 7%) vs handoff entries (reduce to 5%) using positionSource tagging
4. Reduce panic-sell threshold from 10% to 4-5%
5. Raise Pivotal minVolumeSurgeRatio from 1.2 to 1.5
6. Catalyst scanStart: change 09:15 to 09:30

### Medium Term (v2)
7. Begin v2 build (see Part 12 for phases)
8. Angel One adapter as first step
9. Supabase schema and migration
10. Docker packaging for single-user deployments

### Business
11. User agreement language: "1% of deployed capital per month" (not % of profits — cleaner SEBI position)
12. Minimum capital for users: ₹5L+ (below this, infra cost exceeds your revenue)
13. Get CA/lawyer review before public launch

---

## PART 16 — DOCUMENTS GENERATED (June 2026)

Three additional specification documents exist alongside this one:

1. **FUNCTIONAL_SPEC.md** — Complete v2 functional specification. Supabase schema with SQL, Angel One flows, multi-tenant architecture, all strategies with exact parameters. Use for v2 build.

2. **HANDOFF.md** — VS Code Claude technical briefing. File-by-file codebase explanation, broker adapter pattern with code examples, build phases, session start instructions.

3. **TRADING_ENGINE_CORE.md** — Trading rules quick reference. All 5 laws, preflight gate sequence, every strategy's entry/exit in full detail, EOD matrix, charge model, position state machine, cron schedule.

---

## HOW TO START A NEW SESSION

### For Claude (claude.ai)
1. Upload this file (MASTER_HANDOFF.md)
2. Say: "Read MASTER_HANDOFF.md. This is DineshTrade. [Your question]"
3. For deep v2 work, also upload FUNCTIONAL_SPEC.md

### For VS Code Claude / Copilot
1. Place MASTER_HANDOFF.md, HANDOFF.md, FUNCTIONAL_SPEC.md, TRADING_ENGINE_CORE.md in repo root
2. Say: "Read MASTER_HANDOFF.md, HANDOFF.md, and TRADING_ENGINE_CORE.md before we start. We are on [Phase N]. Today's task: [X]"

### After Each Work Session
Update the "OPEN ITEMS" section above with:
- What was completed
- What changed
- What comes next
- Any new decisions made

---

*DineshTrade — Built by Dinesh Wadhwani, June 2026*  
*"Never sell at a loss. Quality stocks always come back."*
